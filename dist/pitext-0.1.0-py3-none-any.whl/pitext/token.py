def tokenize(sentence: str) -> list[str]:
  return sentence.split()
