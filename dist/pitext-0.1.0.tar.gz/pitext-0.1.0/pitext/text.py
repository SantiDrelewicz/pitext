def process(sentence: str) -> str:
  return sentence.lower()
