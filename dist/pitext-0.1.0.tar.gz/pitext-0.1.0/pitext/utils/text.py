def process(sentence: str) -> str:
  return sentence.lower()

def helper_function(text: str) -> str:
    return text.upper()