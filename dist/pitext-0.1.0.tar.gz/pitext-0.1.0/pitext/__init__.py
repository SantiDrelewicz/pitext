from .text import process

__all__ = ["process"]
