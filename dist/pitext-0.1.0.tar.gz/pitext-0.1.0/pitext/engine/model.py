class Model:
    def __init__(self):
        print("Model initialized")